<?php
	session_start();
	if($_SESSION['sid']=="")
	{
		header('location:index.php');
	}
	else
	{
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Panel</title>
<!-- 
Cafe House Template
http://www.templatemo.com/tm-466-cafe-house
-->
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,700' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Damion' rel='stylesheet' type='text/css'>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <link href="css/templatemo-style.css" rel="stylesheet">
  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
  <link rel="stylesheet" href="css/style.css">

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>
    <!-- Preloader -->
    <div id="loader-wrapper">
      <div id="loader"></div>
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
    </div>
    <!-- End Preloader -->
    <div class="tm-top-header">
      <div class="container">
        <div class="row">
          <div class="tm-top-header-inner">
            <div class="tm-logo-container">
              <img src="img/logo.png" alt="Logo" class="">
              <h1 class="tm-site-name tm-handwriting-font">Cafe House</h1>
            </div>
            <div class="mobile-menu-icon">
              <i class="fa fa-bars"></i>
            </div>
            <nav class="tm-nav">
              <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="insert.php">Insert</a></li>
                <li><a href="product.php">Products</a></li>
                <li><a href="order.php">Orders</a></li>
                <li><a href="feedback.php" class="active">Feedbacks</a></li>
                <li><a href="logout.php">Logout</a></li>
              </ul>
            </nav>   
          </div>           
        </div>    
      </div>
    </div>
    <!-- <section class="tm-welcome-section"> -->
        <div class="container tm-position-relative">
            <div class="tm-lights-container">
                <img src="img/light.png" alt="Light" class="light light-1">
                <img src="img/light.png" alt="Light" class="light light-2">
                <img src="img/light.png" alt="Light" class="light light-3">  
            </div>
            <div class="row tm-welcome-content">
                <div style="height: 150px; margin-top: 100px;">
                    <h2 align="center" style="color: #c79c60;">Feedback Messages</h2>
                    <table  style="border-color:#000000;border-style: dotted;margin-left:-178px;" width="1000px" align="left" >
                        <tr>
                            <th width="100px" height="50px">ID:</th>					
                            <th width="100px" height="50px">Name:</th>
                            <th width="100px" height="50px">Email:</th>
                            <th width="100px" height="50px">Phone:</th>	
                            <th width="100px" height="50px">Message:</th>						
                        </tr>	
                        <?php
                            error_reporting(1);
                            include("connection.php");
                                $sel=mysql_query("select * from content ");
                                while($row=mysql_fetch_array($sel))
                                    {		
                                        $id=$row['con_id'];					
                                        $name=$row['name'];
                                        $email=$row['email'];
                                        $phone=$row['phone'];
                                        $mesg=$row['mesg'];
                                            
                        ?>
                        <tr>
                            <td width="100px" height="50px"><?php echo $id; ?></td>
                            <td width="100px" height="50px"><?php echo $name; ?></td>
                            <td width="100px" height="50px"><?php echo $email; ?></td>
                            <td width="100px" height="50px"><?php echo $phone; ?></td>
                            <td width="100px" height="50px"><?php echo $mesg; ?></td>                       
                        </tr>			
                        <?php } ?>
                    </table>
                </div>
            </div>
        </div> 
    </section>
<?php } ?>
    <script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>      <!-- jQuery -->
    <script type="text/javascript" src="js/templatemo-script.js"></script>      <!-- Templatemo Script -->

 </body>
 </html>