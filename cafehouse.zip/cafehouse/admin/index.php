<?php
  session_start();
  error_reporting(1);
  include("connection.php");
  if(isset($_POST['log']))
  {
    if($_POST['id']=="" || $_POST['pwd']=="")
    {
      $err="fill your id and password first";
    }
    else 
    {
      $d=mysql_query("select * from user where name='{$_POST['id']}' ");
      $row=mysql_fetch_object($d);
      $fid=$row->name;
      $fpass=$row->pass; 
      if($fid==$_POST['id'] && $fpass==$_POST['pwd'])
      {
        $_SESSION['sid']=$_POST['id'];
        header('location:home.php');
      }
      else
      {
        $er=" your password is not";
      }
    }
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Panel</title>
<!-- 
Cafe House Template
http://www.templatemo.com/tm-466-cafe-house
-->
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,700' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Damion' rel='stylesheet' type='text/css'>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <link href="css/templatemo-style.css" rel="stylesheet">
  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
  <link rel="stylesheet" href="css/style.css">

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>
    <!-- Preloader -->
    <div id="loader-wrapper">
      <div id="loader"></div>
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
    </div>
    <!-- End Preloader -->

    <!-- <section class="tm-welcome-section"> -->
      <div class="container tm-position-relative">
        <div class="tm-lights-container">
          <img src="img/light.png" alt="Light" class="light light-1">
          <img src="img/light.png" alt="Light" class="light light-2">
          <img src="img/light.png" alt="Light" class="light light-3">  
        </div>
        <div class="row tm-welcome-content">
            <div class="formdiv">
                <center>
                    <form method="post" class="form">
                        <table>
                            <tr>
                                <td><img src="img/logo.png"></td>
                                <td style="color:white; font-size: 20px;">Welcome Admin</td>
                            </tr>
                            <tr>
                                <td style="color:white;">Username</td>
                                <td><input type="text" id="id" name="id"></td>
                            </tr>
                            <tr>
                                <td style="color:white;">Password</td>
                                <td><input type="password" id="pwd" name="pwd"></td>
                            </tr>
                            <tr>
                              <td></td>
                              <td class="c3">
                                  <input type="reset" value="clear">
                                  <input type="submit" name="log" id="log" value="login">
                                </td>
                            </tr>
                        </table>
                    </form>
                </center>
            </div>
        </div>
        <img src="img/table-set.png" alt="Table Set" class="tm-table-set img-responsive">
      </div>      
    </section>
    
     <!-- Footer content-->  
   <!-- JS -->
   <script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>      <!-- jQuery -->
   <script type="text/javascript" src="js/templatemo-script.js"></script>      <!-- Templatemo Script -->

 </body>
 </html>